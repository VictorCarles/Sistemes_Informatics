#!/bin/bash

echo=`Donam el nom d'usuari`;

#Demane disculpes a qui tinga que corregir aquest examen.
#Att. Victor.